// Variables y Objetos globales.
var v_mapa = null;

function cargarMapa(){
	// Asuncion - Paraguay.
	var v_longitud = -57.6309129;
	var v_latitud = -25.2961407;
	var v_zoom = 14;

	var style = 'osm-intl';
	var server = 'https://maps.wikimedia.org/';

	// Se crea el mapa.
	var map = L.map('mapa').setView([v_latitud, v_longitud], v_zoom);

	// Se agrega al mapa el layer de la Wikimedia.
	L.tileLayer(server + style + '/{z}/{x}/{y}.png', {
	    maxZoom: 18,
	    id: 'wikipedia-map-01',
	    attribution: 'Wikimedia maps beta | Map data &copy; <a href="http://openstreetmap.org/copyright">OpenStreetMap contributors</a>'
	}).addTo(map);
}
