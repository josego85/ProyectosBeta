// Variables y Objetos globales.
var v_mapa = null;

function cargarMapa(){
	// Asuncion - Paraguay.
	var v_longitud = -57.6309129;
	var v_latitud = -25.2961407;
	var v_zoom = 10;

	// Mapbox.
	L.mapbox.accessToken = 'pk.eyJ1IjoidGNxbCIsImEiOiJaSlZ6X3JZIn0.mPwXgf3BvAR4dPuBB3ypfA';
	v_mapa = L.mapbox.map('mapa', 'mapbox.streets').setView([v_latitud, v_longitud], v_zoom);

	// Mapa de calor.
	var heat = L.heatLayer([
	    [-25.4561407, -57.6309129, 255],
		[-25.4561417, -57.6309429, 5],
		[-25.4561427, -57.6309929, 35],
	    [-25.2961447, -57.620933, 133]
	]).addTo(v_mapa);

}
