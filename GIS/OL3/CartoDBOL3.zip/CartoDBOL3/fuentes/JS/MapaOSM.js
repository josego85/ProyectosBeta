// Variables y objetos globales.
var v_mapa = null;
var v_cartoDBSource = null;
var v_zoom = null;

function cargarMapa(){
	v_zoom = 1;

	v_layer_mapquest = new ol.layer.Tile({
	    style: 'Road',
	    source: new ol.source.MapQuest({
	    	layer: 'osm'
	    })
	});

	var v_mapConfig = {
		'layers': [{
		    'type': 'cartodb',
		    'options': {
		        'cartocss_version': '2.1.1',
		        'cartocss': '#layer { polygon-fill: #F00; }',
				'sql': 'select * from european_countries_e where area > 0'
		    }
	  	}]
	};

    v_cartoDBSource = new ol.source.CartoDB({
	  account: 'documentation',
	  config: v_mapConfig
	});

	v_mapa = new ol.Map({
        target: 'mapa',
        renderer: 'canvas',
        layers: [
			new ol.layer.Tile({
      			source: new ol.source.OSM()
    		}),
			new ol.layer.Tile({
      			source: v_cartoDBSource
    		})
    	],
    	view: new ol.View({
    		center: [0, 0],
            zoom: v_zoom
    	})
 	});
}
