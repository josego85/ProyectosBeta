// Variables y objetos globales.
var v_mapa = null;
var v_layer_mapquest = null;
var v_latitud = null;
var v_longitud = null;

function cargarMapa(){
	v_longitud = -0.669153504108028;
	v_latitud = 51.365908344379;

	var v_ciudad_asuncion = ol.proj.transform([v_longitud, v_latitud], 'EPSG:4326', 'EPSG:3857');

	v_layer_mapquest = new ol.layer.Tile({
	    style: 'Road',
	    source: new ol.source.MapQuest({
	    	layer: 'osm'
	    })
	});

	v_mapa = new ol.Map({
        target: 'mapa',
        renderer: 'canvas',
        layers: [
            v_layer_mapquest
    	],
    	view: new ol.View({
    		center: v_ciudad_asuncion,
            zoom: 12
    	})
 	});

	// Layer marcadores.
	var v_marcadores = new ol.layer.Vector({
		source: new ol.source.Vector({
			'projection': v_mapa.getView().getProjection(),
    		'url': 'http://digitalservices.surreyi.gov.uk/developmentcontrol/0.1/applications/search?status=live&gsscode=E07000214&status=live',
        	format: new ol.format.GeoJSON()
    	}),
	    style: new ol.style.Style({
	        image: new ol.style.Icon(({
	            anchor: [0.5, 40],
	            anchorXUnits: 'fraction',
	            anchorYUnits: 'pixels',
	            src: '../recursos/Img/location-pointer.png'
	        }))
	    })
	});

	// Agregar el layer marcadores al mapa.
	v_mapa.addLayer(v_marcadores);
}
