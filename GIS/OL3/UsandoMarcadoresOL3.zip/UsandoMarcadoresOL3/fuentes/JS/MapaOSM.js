// Variables y Objetos globales.
var v_mapa = null;
var v_layer_mapquest = null;
var v_latitud = null;
var v_longitud = null;

function cargarMapa(){
	// Asuncion - Paraguay.
	v_longitud = -57.6309129;
	v_latitud = -25.2961407;			 
	
	var v_ciudad_asuncion = ol.proj.transform([v_longitud, v_latitud], 'EPSG:4326', 'EPSG:3857');
	
	v_layer_mapquest = new ol.layer.Tile({
	    style: 'Road',
	    source: new ol.source.MapQuest({
	    	layer: 'osm'
	    })
	});

	v_mapa = new ol.Map({
        target: 'mapa',
        renderer: 'canvas',
        layers: [
            v_layer_mapquest
    	],
    	view: new ol.View({
    		center: v_ciudad_asuncion,
            zoom: 6
    	})
 	});

	// Marcador 1.
	var v_longitud_marcador1 = -57.1209129;
	var v_latitud_marcador1 = -25.9961407;
	var v_punto1 = ol.proj.transform([v_longitud_marcador1, v_latitud_marcador1], 'EPSG:4326', 'EPSG:3857');
	var v_marcador1 = new ol.Overlay({
        map: v_mapa,
		position: v_punto1,
		element: document.getElementById('marcador1')
	});
	v_mapa.addOverlay(v_marcador1);
	
	// Marcador 2.
	var v_longitud_marcador2 = -57.8977;
	var v_latitud_marcador2 = -25.34556;
	var v_punto2 = ol.proj.transform([v_longitud_marcador2, v_latitud_marcador2], 'EPSG:4326', 'EPSG:3857');
	var v_marcador2 = new ol.Overlay({
        map: v_mapa,
		position: v_punto2,
		element: document.getElementById('marcador2')
	});
	v_mapa.addOverlay(v_marcador2);
	
	// Marcador 3.
	var v_longitud_marcador3 = -57.458977;
	var v_latitud_marcador3 = -25.3456556;
	var v_punto3 = ol.proj.transform([v_longitud_marcador3, v_latitud_marcador3], 'EPSG:4326', 'EPSG:3857');
	var v_marcador3 = new ol.Overlay({
        map: v_mapa,
		position: v_punto3,
		element: document.getElementById('marcador3')
	});
	v_mapa.addOverlay(v_marcador3);
} 
