// Variables y Objetos globales.
var mapa = null;

function cargarMapa(){
    var layer_countries = new ol.layer.Tile({
        title: 'Countries',
        source: new ol.source.TileWMS({
            url: 'http://demo.opengeo.org/geoserver/wms',
            params: {'LAYERS': 'ne:ne_10m_admin_1_states_provinces_lines_shp'},
            serverType: 'geoserver'
        })
    });
    // Evento change del layer layer_countries.
    layer_countries.on('change:visible', function(layer){
        if(!layer.oldValue){
            alert("Entro Layer Countries");
        }
    });

    var layer_base1 = new ol.layer.Tile({
        source: new ol.source.Stamen({
            layer: 'watercolor'
        })
    });
    var group_layer_countries = new ol.layer.Group({
        title: 'Overlays',
        layers: [
            layer_countries
        ]
    });

    var mapa = new ol.Map({
        target: 'mapa',
        layers: [
            new ol.layer.Group({
                'title': 'Base maps',
                layers: [
                    new ol.layer.Group({
                        title: 'Water color with labels',
                        type: 'base',
                        combine: true,
                        visible: false,
                        layers: [
                            layer_base1,
                            new ol.layer.Tile({
                                source: new ol.source.Stamen({
                                    layer: 'terrain-labels'
                                })
                            })
                        ]
                    }),
                    new ol.layer.Tile({
                        title: 'Water color',
                        type: 'base',
                        visible: false,
                        source: new ol.source.Stamen({
                            layer: 'watercolor'
                        })
                    }),
                    new ol.layer.Tile({
                        title: 'OSM',
                        type: 'base',
                        visible: true,
                        source: new ol.source.OSM()
                    })
                ]
            }),
            group_layer_countries
        ],
        view: new ol.View({
            center: ol.proj.transform([0, 0], 'EPSG:4326', 'EPSG:3857'),
            zoom: 3
        })
    });

    var layerSwitcher = new ol.control.LayerSwitcher({
        tipLabel: 'Leyenda'
    });
    mapa.addControl(layerSwitcher);
}
