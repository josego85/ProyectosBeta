// Variables y Objetos globales.
var mapa = null;

function cargarMapa(){
	// Asuncion - Paraguay.
	var longitud = -57.6309129;
	var latitud = -25.2961407;
	var asuncion = ol.proj.transform([longitud, latitud], 'EPSG:4326', 'EPSG:3857');

	var layer_mapquest = new ol.layer.Tile({
	    style: 'Road',
	    source: new ol.source.MapQuest({
	    	layer: 'osm'
	    })
	});

	mapa = new ol.Map({
        target: 'mapa',
        renderer: 'canvas',
        layers: [
            layer_mapquest
    	],
    	view: new ol.View({
    		center: asuncion,
            zoom: 8
    	})
 	});

	var geojson_layer = new ol.layer.Vector({
		title: 'Puntos',
    	style: new ol.style.Style({
		    image: new ol.style.Circle({
		        fill: new ol.style.Fill({
					color: 'red'
				}),
		        stroke: new ol.style.Stroke({
					color: 'black',
					width: 1
				}),
		        radius: 5
		    })
    	}),
		source: new ol.source.Vector({
			url: "http://localhost/mapaPuntos/fuentes/puntos.php",
			format: new ol.format.GeoJSON()
	    })
	});
	// Se agrega el layer en el mapa.
	mapa.addLayer(geojson_layer);
}
