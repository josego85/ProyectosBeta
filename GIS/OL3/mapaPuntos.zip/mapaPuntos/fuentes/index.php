<html>
<head>
    <title>Puntos OpenLayers 3</title>
    <link rel="stylesheet" href="JS/libs/OL3/ol.css" type="text/css">
    <style>
        #mapa {
            height: 80%;
            width: 100%;
        }
    </style>
    <script src="JS/libs/OL3/ol.js" type="text/javascript"></script>
    <script src="JS/MapaOSM.js" type="text/javascript"></script>
</head>
<body onLoad="cargarMapa()">
    <div id="mapa">
    </div>
</body>
</html>
