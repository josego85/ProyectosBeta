<?php
    // Coneccion a la base de datos.
    mysql_connect('localhost','root','123456');
    mysql_select_db('puntos') OR DIE ("Error: No es posible establecer la conexión");

    // Consulta a la base de datos.
    $result = mysql_query('SELECT longitud,latitud FROM coordenadas');

    $geojson = array(
        'type' => 'FeatureCollection',
        'features' => array()
    );

    // Add edges to GeoJSON array.
    if($result){
        while($row = mysql_fetch_array($result)) {
            $feature = array(
                'type' => 'Feature',
                'geometry' => array(
                    'type' => 'Point',
                    'coordinates' => array((float)$row[0], (float)$row[1])
                )
            );
            // Add feature array to feature collection array
            array_push($geojson['features'], $feature);
        }
    }
    // Return routing result
    header('Content-type: application/json',true);
    echo json_encode($geojson);
?>
