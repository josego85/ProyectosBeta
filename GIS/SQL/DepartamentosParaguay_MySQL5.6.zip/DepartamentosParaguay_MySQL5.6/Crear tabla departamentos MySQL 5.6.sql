CREATE TABLE `departamentos` (
  `departamento_id` int(2) NOT NULL,
  `departamento_nombre` varchar(250) DEFAULT NULL,
  `departamento_capital` varchar(250) DEFAULT NULL,
  `geom` geometry NOT NULL,
  UNIQUE KEY `i_departamentoids` (`departamento_id`),
  SPATIAL KEY `i_geomidx` (`geom`)
) ENGINE=MYISAM DEFAULT CHARSET=utf8;
